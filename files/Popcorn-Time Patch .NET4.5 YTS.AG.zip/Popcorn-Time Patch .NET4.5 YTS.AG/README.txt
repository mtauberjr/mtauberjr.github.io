Popcorn-Time Patch (.NET v4.5) YTS.AG
This patcher will change your current popcorntime API to the one from yts.ag. Use their API at your own risk.

1. Popcorn-Time must be installed in the default location. (%userprofile%\AppData\Local\Popcorn Time)
2. Click the Popcorn-Time executable and click patch.
3. If the patch doesn't work try copy pasting the .js files manually.

!This is not an official Popcorn-Time patch.